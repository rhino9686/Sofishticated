
struct Tank {
  //We store everything as a integer here, will be the actual value multiplied by 100 to get 2 decimal places
  int temperature;
  int pH;
  int ammoniaReading;
  int nitrateReading;

};
